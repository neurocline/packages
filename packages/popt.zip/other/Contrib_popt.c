//=================================================================================================
// Contrib/popt/Contrib_popt.c
//
// Contrib_popt.c is a bundle file for all popt files. Include this instead
// of including individual files from popt. This is a convenience file to make
// it easier to add popt in source-form to a project.
//
// Copyright 2007 Blizzard Entertainment. All rights reserved.
//=================================================================================================

// NOTE: Use Warning Level 0

// These files are in a magic order to get all the code to compile together
// without altering them too much.

#if !defined (_XBOX) && !defined (_PS3)
#include "findme.c"
#include "popt.c"
#include "popthelp.c"
#include "poptparse.c"
#endif
